package android.example.hzi_4labor;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    ListView listView;
    String iTitle[]={"EUR","USD","GBP","AUD","CAD","CHF","DKK","HUF"};
    String iDescription[]={"EURO","Dolar american","Lira sterlina","Dolar australian","Dolar canadian","Franc elvetian","Coroana daneza","Forint maghiar"};
    int image[]={R.drawable.european_union,R.drawable.united_states,R.drawable.united_kingdom,R.drawable.australia,R.drawable.canada,R.drawable.switzerland,R.drawable.denmark,R.drawable.hungary};
    String[] vasarar = {"4,4100", "3,9750", "6,1250", "2,9600", "3,0950", "4,2300", "0,5850", "0,0136"};

    String[] eladar = {"4,5500", "3,9750", "6,3550", "3,0600", "3,2650", "4,3300", "0,6150", "0,0146"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView=findViewById(R.id.listView);
        MyAdapter adapter=new MyAdapter(this,iTitle,iDescription,image,vasarar,eladar);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {

                TextView textview3=view.findViewById(R.id.textView3);
                TextView textview4=view.findViewById(R.id.textView4);
                TextView textview5=view.findViewById(R.id.textView5);
                TextView textview6=view.findViewById(R.id.textView6);
                textview3.setVisibility(View.VISIBLE);
                textview4.setVisibility(View.VISIBLE);
                textview5.setVisibility(View.VISIBLE);
                textview6.setVisibility(View.VISIBLE);

            }
        });


    }
    class MyAdapter extends ArrayAdapter<String>{
        Context context;
        String iTitle[];
        String iDescription[];
        int image[];
        String vasarar[];
        String eladar[];
        MyAdapter(Context c,String iTitle[],String iDescription[],int image[],String eladar[],String vasarar[]){
            super(c,R.layout.listview_layout,iTitle);
            this.context=c;
            this.iTitle=iTitle;
            this.iDescription=iDescription;
            this.image=image;
            this.eladar=eladar;
            this.vasarar=vasarar;
        }
        public View getView(int position, View view, ViewGroup parent) {
            LayoutInflater inflater = (LayoutInflater)getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View row = inflater.inflate(R.layout.listview_layout,null,true);

            ImageView images = row.findViewById(R.id.imageView);
            TextView iTitle1 =row.findViewById(R.id.textView1);
            TextView iDescription1 = row.findViewById(R.id.textView2);
            TextView vasarar1 = row.findViewById(R.id.textView5);
            TextView eladar1 = row.findViewById(R.id.textView6);

            images.setImageResource(image[position]);
            iTitle1.setText(iTitle[position]);
            iDescription1.setText(iDescription[position]);
            vasarar1.setText(vasarar[position]);
            eladar1.setText(eladar[position]);

            return row;

        }
    }
}