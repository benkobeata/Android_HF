package android.example.benkobeata_hf01;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText e1,e2;
    TextView t1;
    int szam1,szam2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public boolean getNumbers(){
        e1=(EditText)findViewById(R.id.szam1);
        e2=(EditText)findViewById(R.id.szam2);
        t1=(TextView)findViewById(R.id.eredmeny);
        String s1 = e1.getText().toString();
        String s2 = e1.getText().toString();
        if((s1.equals(null)&&s2.equals(null))||(s1.equals(" ")&& s2.equals(" "))){
            String eredmeny="Kerlek adjon meg ertekeket.";
            t1.setText(eredmeny);
            return false;
        }
        else{
           szam1=Integer.parseInt(e1.getText().toString());
            szam2=Integer.parseInt(e2.getText().toString());
        }
        return true;

    }
    public void osszeadas(View v){
        if(getNumbers()){
            int osszeg=szam1+szam2;
            t1.setText(Integer.toString(osszeg));
        }
    }
    public void kivonas(View v){
        if(getNumbers()){
            int osszeg=szam1-szam2;
            t1.setText(Integer.toString(osszeg));
        }
    }
    public void szorzas(View v){
        if(getNumbers()){
            int osszeg=szam1*szam2;
            t1.setText(Integer.toString(osszeg));
        }
    }
    public void osztas(View v){
        if(getNumbers()){
            double osszeg=szam1/szam2;
            t1.setText(Double.toString(osszeg));
        }
    }
    public void maradek(View v){
        if(getNumbers()){
            int osszeg=szam1%szam2;
            t1.setText(Integer.toString(osszeg));
        }
    }
    public void hatvanyozas(View v){
        if(getNumbers()){
            double osszeg=Math.pow(szam1,szam2);
            t1.setText(Double.toString(osszeg));
        }
    }
}