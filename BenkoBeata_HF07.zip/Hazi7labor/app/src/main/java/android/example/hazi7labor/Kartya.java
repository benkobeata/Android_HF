package android.example.hazi7labor;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Kartya implements Serializable {
    private String penznem;
    private String leiras;
    private int image;
    private String vasarlas;
    private String eladas;
    private String eladasiar;
    private String vasarlasiar;

    public Kartya(String penznem, String leiras,String vasarlas,String eladas, int image, String eladasiar, String vasarlasiar) {
        this.penznem = penznem;
        this.leiras = leiras;
        this.eladasiar = eladasiar;
        this.vasarlasiar = vasarlasiar;
        this.eladas=eladas;
        this.vasarlas=vasarlas;
        this.image=image;
    }

    public String getPenznem() {
        return penznem;
    }

    public String getLeiras() {
        return leiras;
    }

    public int getImage() {
        return image;
    }

    public String getEladasiar() {
        return eladasiar;
    }

    public String getVasarlasiar() {
        return vasarlasiar;
    }

    public static List<Kartya> getKartya()
    {
        List<Kartya> kartyaList=new ArrayList<>();
        kartyaList.add(
                new Kartya("EUR",
                        "EURO",
                        "Cumpar",
                        "Vinde",
                        R.drawable.european_union,
                        "4,5500",
                        "4,4100"
                )
        );
        kartyaList.add(
                new Kartya("USD",

                        "Dollar",
                        "Cumpar",
                        "Vinde",
                        R.drawable.united_states,
                        "3,9750",
                        "3,9750"

                )
        );
        kartyaList.add(
                new Kartya("GBP",
                        "Lira sterlina",
                        "Cumpar",
                        "Vinde",
                        R.drawable.united_kingdom,
                        "6,3550",
                        "6,1550"
                )
        );
        kartyaList.add(
                new Kartya("AUD",
                        "Dolar australian",
                        "Cumpar",
                        "Vinde",
                        R.drawable.australia,
                        "3,0600",
                        "2,9600"
                )
        );
        kartyaList.add(
                new Kartya("CAD",
                        "Dolar canadian",
                        "Cumpar",
                        "Vinde",
                        R.drawable.canada,
                        "3,2650",
                        "3,0950"
                )
        );
        kartyaList.add(
                new Kartya("CHF",
                        "France elvetian",
                        "Cumpar",
                        "Vinde",

                        R.drawable.switzerland,
                        "4,3300",
                        "4,2300"
                )
        );
        kartyaList.add(
                new Kartya("DKK",
                        "Coroana daneza",
                        "Cumpar",
                        "Vinde",
                        R.drawable.denmark,
                        "0,6150" ,
                        "0,5850"));
        kartyaList.add(
                new Kartya("HUF",
                        "Forint maghiar",
                        "Cumpar",
                        "Vinde",
                        R.drawable.hungary,
                        "0,0146",
                        "0,0136"        ));
        return kartyaList;
    }
}

