package android.example.hazi7labor;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class Kartya_Adapter extends RecyclerView.Adapter<Kartya_Adapter.KartyaViewHolder> {
    private Activity mCtx;
    private List<Kartya> kartyalista;

    public Kartya_Adapter(Activity mCtx, List<Kartya> kartyalista) {
        this.mCtx = mCtx;
        this.kartyalista = kartyalista;
    }

    @Override
    public KartyaViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_main, parent, false);
        return new KartyaViewHolder(itemView, mCtx);
    }
    @Override
    public void onBindViewHolder(KartyaViewHolder holder, int position) {
        Kartya kartya=kartyalista.get(position);
        holder.rootView.setTag(kartya);
        holder.textView1.setText(kartya.getPenznem());
        holder.textView2.setText(kartya.getLeiras());
        holder.textView5.setText(kartya.getVasarlasiar());
        holder.textView6.setText(kartya.getEladasiar());
        holder.imageView.setImageDrawable(mCtx.getResources().getDrawable(kartya.getImage(),null));
    }
    @Override
    public int getItemCount() {
        return kartyalista.size();
    }

    class KartyaViewHolder extends RecyclerView.ViewHolder{
        ImageView imageView;
        TextView textView1,textView2,textView3,textView4,textView5,textView6;
        View rootView;
        public KartyaViewHolder(View itemView,final Context context) {
            super(itemView);
            rootView=itemView;
            imageView = itemView.findViewById(R.id.imageView);
            textView1 =itemView.findViewById(R.id.textView1);
            textView2 = itemView.findViewById(R.id.textView2);
            textView3 =itemView.findViewById(R.id.textView3);
            textView4 = itemView.findViewById(R.id.textView4);
            textView5 = itemView.findViewById(R.id.textView5);
            textView6 = itemView.findViewById(R.id.textView6);

            itemView.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v){
                    textView3.setVisibility(v.VISIBLE);
                    textView4.setVisibility(v.VISIBLE);
                    textView5.setVisibility(v.VISIBLE);
                    textView6.setVisibility(v.VISIBLE);
                }
            });
        }
    }
}

